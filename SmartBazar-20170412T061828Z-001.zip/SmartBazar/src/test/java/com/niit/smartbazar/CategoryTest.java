package com.niit.smartbazar;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.smartbazar.dao.CategoryDAO;
import com.niit.smartbazar.bean.Category;






public class CategoryTest {
	public static void main(String[]args){
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.smartbazar");
		context.refresh();
		CategoryDAO categoryDAO =  (CategoryDAO) context.getBean("categoryDAO");
		
		Category category =  (Category) context.getBean("category");
		
		category.setId(101);
		
		category.setName("CGNAME120");
		
		category.setDescription("CGDesc120");
		
		categoryDAO.saveorUpdate(category);
		
		
		/*if( categoryDAO.get(101) == null)
		{
			System.out.println("Category does not exist");
		}
		else
		{
			System.out.println("Category exist .. the details are ...");
			System.out.println();
		}*/
	}
}
		
		
		