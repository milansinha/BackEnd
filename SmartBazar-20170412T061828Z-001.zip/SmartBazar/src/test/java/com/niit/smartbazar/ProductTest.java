package com.niit.smartbazar;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.smartbazar.bean.Category;
import com.niit.smartbazar.bean.Product;

public class ProductTest {
	public static void main(String[]args){
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.smartbazar.bean");
		context.refresh();
		
		/* Product p=(Product)context.getBean("product");
		if  (p != null) {
			System.out.println("Product object is created");
			Category c = p.getCategory();
			
			if  (c != null) {
				System.out.println("category of the product aslo created");
			}else{
				System.out.println("But Category of product also created");
			}
			}
		*/}
		
			
		}
		
