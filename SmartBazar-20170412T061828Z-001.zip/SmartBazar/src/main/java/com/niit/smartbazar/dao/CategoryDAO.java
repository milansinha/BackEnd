package com.niit.smartbazar.dao;

import java.util.List;
import com.niit.smartbazar.bean.Category;


public interface CategoryDAO {

	// declare the methods related to CRUD operations
	// access_specifier return_type method_name(parameter_list) throws
	// exception_list

	// get all categories

	public List<Category> list();
	
	public Category get (int id);
	
	public void saveorUpdate(Category category);
	
	public void delete (int id);
	
}