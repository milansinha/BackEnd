package com.niit.smartbazar.dao.impl;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.smartbazar.bean.user;
import com.niit.smartbazar.dao.UserDAO;



@Transactional
@Repository("UserDAO")
public abstract class UserDAOImpl implements UserDAO {
	
	
	@Autowired
	private SessionFactory sessionFactory;


	public List<user> list() {
		//select * from category  -SQL Query - mention the table name
		//from Category  -> HQL -mention Domain class name not table name
		
		//convert the hibernate query into db specific language
	return	sessionFactory.getCurrentSession().createQuery("from user").list();
		
	}

	public boolean save(user user) {
		try
		{
		sessionFactory.getCurrentSession().save(user);
		return true;
		} catch(Exception e)
		{
			e.printStackTrace(); //it will print the error in the console - similar to SOP
			          //package, class, method line number from which place you are calling
			return false;
		}
		
	}

	public boolean update(user user) {
		try {
			sessionFactory.getCurrentSession().update(user);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
			
		}
	}


	public boolean delete(String mailid) {
		try {
			sessionFactory.getCurrentSession().delete(getuserBymailid(mailid));
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	
	//cntrl + O

	public boolean delete(user user) {
		try {
			sessionFactory.getCurrentSession().delete(user);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
			
		}
	}

	/**
	 * This method will return Category based on category id.
	 * If the category does not exist with this id, it will return null
	 */
	public user getuserBymailid(String mailid) {
		
	return (user)	sessionFactory.getCurrentSession().get(user.class, mailid);
		
	}

	public user getuserByName(String name) {
		// select * from category where name ='mobile'
		
	return	 (user)sessionFactory.getCurrentSession().createQuery("from user where name ='"+name+"'").uniqueResult();
		
		
	}
	
	public user getuserBypassword(String password) {
		
		return (user)	sessionFactory.getCurrentSession().get(user.class, password);
			
		}
	
	public user getuserByContact(int contact) {
		// select * from category where contact = "1235"
		
	return	 (user)sessionFactory.getCurrentSession().createQuery("from user where contact ='"+contact+"'").uniqueResult();
		
		
	}
	
	
	

}

