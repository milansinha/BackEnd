package com.niit.smartbazar.dao.impl;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.smartbazar.bean.Supplier;
import com.niit.smartbazar.dao.SupplierDAO;



@Transactional
@Repository("SupplierDAO")
public class SupplierDAOImpl implements SupplierDAO {
	
	
	@Autowired
	private SessionFactory sessionFactory;


	public List<Supplier> list() {
		//select * from category  -SQL Query - mention the table name
		//from Category  -> HQL -mention Domain class name not table name
		
		//convert the hibernate query into db specific language
	return	sessionFactory.getCurrentSession().createQuery("from Supplier").list();
		
	}

	public boolean save(Supplier supplier) {
		try
		{
		sessionFactory.getCurrentSession().save(supplier);
		return true;
		} catch(Exception e)
		{
			e.printStackTrace(); //it will print the error in the console - similar to SOP
			          //package, class, method line number from which place you are calling
			return false;
		}
		
	}

	public boolean update(Supplier supplier) {
		try {
			sessionFactory.getCurrentSession().update(supplier);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
			
		}
	}


	public boolean delete(String id) {
		try {
			sessionFactory.getCurrentSession().delete(getSupplierByID(id));
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	
	//cntrl + O

	public boolean delete(Supplier supplier) {
		try {
			sessionFactory.getCurrentSession().delete(supplier);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
			
		}
	}

	/**
	 * This method will return Category based on category id.
	 * If the category does not exist with this id, it will return null
	 */
	public Supplier getSupplierByID(String id) {
		
	return (Supplier)	sessionFactory.getCurrentSession().get(Supplier.class, id);
		
	}

	public Supplier getSupplierByName(String name) {
		// select * from category where name ='mobile'
		
	return	 (Supplier)sessionFactory.getCurrentSession().createQuery("from Supplier where name ='"+name+"'").uniqueResult();
		
		
	}
	
	public Supplier getSupplierByAdress(String adress) {
		// select * from supplier where adress ='bhubhaneswar'
		
	return	 (Supplier)sessionFactory.getCurrentSession().createQuery("from Supplier where name ='"+adress+"'").uniqueResult();
	
	
	
	

	}
}

