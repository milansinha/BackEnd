package com.niit.smartbazar.dao;

import java.util.List;

import com.niit.smartbazar.bean.Supplier;



public interface SupplierDAO {

	// declare the methods related to CRUD operations
	// access_specifier return_type method_name(parameter_list) throws
	// exception_list

	// get all categories

	public List<com.niit.smartbazar.bean.Supplier> list();

	// create category

	public boolean save(Supplier supplier);

	// update category

	public boolean update(Supplier supplier);

	// delete category by id

	public boolean delete(String id);

	// delete category by category

	public boolean delete(Supplier supplier);

	// get category by id

	public Supplier getSupplierByID(String id);

	// get category by name
	public Supplier getSupplierByName(String name);
	
	//get supplier by adress
	public Supplier getSupplierByAdress(String adress);

}

