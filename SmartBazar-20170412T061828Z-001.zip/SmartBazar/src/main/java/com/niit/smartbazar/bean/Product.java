package com.niit.smartbazar.bean;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Entity
@Table
@Component
public class Product {
	private String id;
	private String name;
	//private Category category;
	
	/*public Category getcategory() {
		return category;
	}
	@Autowired
	public void setCategory(Category category){
		this.category = category;
	}*/
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
