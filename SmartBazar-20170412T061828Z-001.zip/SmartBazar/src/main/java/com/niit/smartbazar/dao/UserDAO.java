package com.niit.smartbazar.dao;

import java.util.List;

import com.niit.smartbazar.bean.user;



public interface UserDAO {

	// declare the methods related to CRUD operations
	// access_specifier return_type method_name(parameter_list) throws
	// exception_list

	// get all categories

	public List<com.niit.smartbazar.bean.user> list();

	// create category

	public boolean save(user user);

	// update category

	public boolean update(user user);

	// delete category by id

	public boolean delete(String mailid);

	// delete category by category

	public boolean delete(user user);

	// get category by id

	public user getuserBymailid(String mailid);

	// get category by name
	public user getuserByName(String name);
	
	// get user by password
	public user getuserByPassword(String password);
	
	// get user by contact
	public user getuserByContact(int contact);
	

}

